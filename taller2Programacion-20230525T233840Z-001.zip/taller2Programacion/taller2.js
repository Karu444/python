/*Construir el algoritmo para un programa que ingrese tres
notas de un alumno, si el promedio es menor o igual a 3.9
mostrar un mensaje "Estudie“, de lo contrario un mensaje que
diga "becado"*/

//Prompt= para imprimir en pantalla texto

//Ejercicio 1
let nombreAlumno = prompt("Ingrese el nombre del alumno:");
let nota1 = prompt("Ingrese la primera nota:");
let nota2 = prompt("Ingrese la segunda nota:");
let nota3 = prompt("Ingrese la tercera nota:");

let promedioNotas = (nota1 + nota2 + nota3) / 3;

if (promedioNotas <= 3.9) {
    console.log("ESTUDIE");
    document.write("ESTUDIE");
}
else {
    console.log("BECADO");
    document.write("BECADO");
}

//Ejercicio 2
/*Dado un número indicar si es par o impar y si es mayor de 10.*/

let numero = prompt("Ingrese un numero:");

if (numero % 2 == 0) {
    console.log("El numero es par");
}
else {
    console.log("El numero es impar");
}
if (numero > 10) {
    console.log("El numero es mayor de 10")
}
else {
    console.log("El numero es menor de 10")
}

//Ejercicio 3
/*Construir el algoritmo para determinar el voltaje de un
circuito a partir de la resistencia y la intensidad de corriente.*/

let resistencia = prompt("Resistencia:");
let intensidadDeCorriente = prompt("intensidadDeCorriente:");
let voltaje = (resistencia * intensidadDeCorriente)

console.log("El voltaje del circulo es:", voltaje);
document.write("El voltaje del circulo es:", voltaje);


//Ejercicio 4
/*Construir el algoritmo que solicite el nombre y edad de 3
personas y determine el nombre de la persona con mayor edad.*/

let personas = [];

//parseInt: Solo recibe numeros enteros,  no decimales
//Ingresar datos
for (let i = 0; i < 3; i++) {
    let nombre = prompt("Ingrese el nombre: ");
    let edad = parseInt(prompt("Ingrese la edad: "));
    personas.push({ nombre: nombre, edad: edad })
}

let mayorEdad = ""
let menorEdad = ""
let ContadorMayor = 0;
let contadorMenor = 0;

//Verificar personas mayor de edad
for (let i = 0; i < personas.length; i++) {
    if (personas[i].edad > 18) {
        if (personas[i].edad > ContadorMayor) {
            ContadorMayor = personas[i].edad
            mayorEdad = personas[i].nombre, personas[i].edad
        }
    //Verificar persona con menor edad
    } else if (personas[i].edad < 18) {
        if (personas[i].edad > contadorMenor) {
            contadorMenor = personas[i].edad
            menorEdad = personas[i].nombre
        } else if (personas[i].edad < contadorMenor) {
            contadorMenor = personas[i].edad
            menorEdad = personas[i].nombre, personas[i].edad
        }
    }
}
console.log(mayorEdad, "Esta es  la persona con mayor edad");
console.log(menorEdad, "Esta es la persona con menos edad");


//Ejercicio 5
/*Construir el algoritmo que lea por teclado dos números,
si el primero es mayor al segundo informar su suma y
diferencia, en caso contrario, informar el producto y la
división del primero respecto al segundo.*/ 

//parseFloat: 
//Ingresar numeros
let datoNumero1= parseFloat (prompt("Ingrese el primer numero:"));
let datoNumero2= parseFloat (prompt("Ingrese el segundo numero:"));

let sumaNumeros= datoNumero1 + datoNumero2;
let resta= datoNumero1 - datoNumero2;
let multiplicacion= datoNumero1 * datoNumero2;
let división= datoNumero1 / datoNumero2;

//Primer numero mayor
if (datoNumero1 > datoNumero2){
    console.log(datoNumero1 + "es mayor a" + datoNumero2 );
    console.log("la suma de" + datoNumero1 + datoNumero2 + 'es igual a:' + sumaNumero);
    console.log("la resta de" + datoNumero1 + datoNumero2 + "es igual a:" + resta);
}
//Segundo numero mayor
else {
    console.log(datoNumero2 + "es mayor que" + datoNumero1);
    console.log("la multiplicacion de" + datoNumero1 + "y" + datoNumero2 + "es:" + multiplicacion);
    console.log("la division de" + datoNumero1 + "y" + datoNumero2 + "es:" + división);
}

//Ejercicio 6
/*Construir el algoritmo en Javascript para un programa
para cualquier cantidad de estudiantes que lea el nombre,
el sexo y la nota definitiva y halle al estudiante con la mayor
nota y al estudiante con la menor nota y cuantos eran
hombres y cuantos mujeres.*/ 

// Solicitar la cantidad de estudiantes al usuario
var cantidadEstudiantes = parseInt(prompt("Ingrese la cantidad de estudiantes:"));

// Variables para almacenar los datos del estudiante con mayor y menor nota
var estudianteMayorNota = "";
var estudianteMenorNota = "";

// Variables para contar la cantidad de hombres y mujeres
var cantidadHombres = 0;
var cantidadMujeres = 0;

// Variable para almacenar la nota máxima y mínima
var notaMaxima = -Infinity;
var notaMinima = Infinity;

// Iterar sobre cada estudiante
for (var i = 1; i <= cantidadEstudiantes; i++) {
  // Solicitar el nombre, sexo y nota del estudiante
  var nombre = prompt("Ingrese el nombre del estudiante " + i + ":");
  var sexo = prompt("Ingrese el sexo del estudiante " + i + " (Hombre o Mujer):");
  var nota = parseFloat(prompt("Ingrese la nota definitiva del estudiante " + i + ":"));

  // Verificar si la nota es la máxima o mínima hasta ahora
  if (nota > notaMaxima) {
    notaMaxima = nota;
    estudianteMayorNota = nombre;
  }

  if (nota < notaMinima) {
    notaMinima = nota;
    estudianteMenorNota = nombre;
  }

  // Verificar el sexo del estudiante y actualizar el contador correspondiente
  if (sexo.toLowerCase() === "hombre") {
    cantidadHombres++;
  } else if (sexo.toLowerCase() === "mujer") {
    cantidadMujeres++;
  }
}

// Mostrar los resultados
console.log("El estudiante con la mayor nota es: " + estudianteMayorNota);
console.log("El estudiante con la menor nota es: " + estudianteMenorNota);
console.log("Cantidad de hombres: " + cantidadHombres);
console.log("Cantidad de mujeres: " + cantidadMujeres);


//Ejercicio 7
/*Programa que pida el ingreso del nombre y precio de un artículo y la
cantidad que lleva el cliente. Mostrar lo que debe pagar el comprador
en su factura.*/ 

// Solicitar al usuario que ingrese el nombre, precio y cantidad del artículo
var nombre = prompt("Ingrese el nombre del artículo:");
var precio = parseFloat(prompt("Ingrese el precio del artículo:"));
var cantidad = parseInt(prompt("Ingrese la cantidad del artículo:"));

// Calcular el monto total a pagar
var total = precio * cantidad;

// Mostrar la factura al comprador
console.log("Factura de compra:");
console.log("Nombre del artículo: " + nombre);
console.log("Precio del artículo: $" + precio);
console.log("Cantidad: " + cantidad);
console.log("Total a pagar: $" + total);

//Ejercicio 8
/*Programa que Ingrese por teclado:
a. el valor del lado de un cuadrado para mostrar por pantalla el
perímetro del mismo
b. la base y la altura de un rectángulo para mostrar el área del
mismo*/ 

// Solicitar al usuario el valor del lado de un cuadrado
var ladoCuadrado = parseFloat(prompt("Ingrese el valor del lado de un cuadrado:"));

// Calcular el perímetro del cuadrado
var perimetroCuadrado = 4 * ladoCuadrado;

// Mostrar el perímetro del cuadrado por pantalla
console.log("El perímetro del cuadrado es: " + perimetroCuadrado);

// Solicitar al usuario la base y altura de un rectángulo
var baseRectangulo = parseFloat(prompt("Ingrese el valor de la base del rectángulo:"));
var alturaRectangulo = parseFloat(prompt("Ingrese el valor de la altura del rectángulo:"));

// Calcular el área del rectángulo
var areaRectangulo = baseRectangulo * alturaRectangulo;

// Mostrar el área del rectángulo por pantalla
console.log("El área del rectángulo es: " + areaRectangulo);

//Ejercicio 9
/*N atletas han pasado a finales en salto triple en los juegos
olímpicos femenino de 2022. Diseñe un programa que pida por
teclado los nombres de cada atleta finalista y a su vez, sus
marcas del salto en metros. Informar el nombre de la atleta
campeona que se quede con la medalla de oro y si rompió
récord, reportar el pago que será de 500 millones. El récord
esta en 15,50 metros.*/ 

// Solicitar al usuario la cantidad de atletas finalistas
var cantidadAtletas = parseInt(prompt("Ingrese la cantidad de atletas finalistas:"));

// Variables para almacenar los datos de la atleta campeona
var nombreCampeona = "";
var marcaCampeona = 0;

// Solicitar al usuario los nombres y marcas de los atletas
for (var i = 1; i <= cantidadAtletas; i++) {
  var nombre = prompt("Ingrese el nombre de la atleta finalista " + i + ":");
  var marca = parseFloat(prompt("Ingrese la marca de salto en metros de la atleta " + i + ":"));

  // Verificar si es la atleta campeona y si rompió el récord
  if (marca > marcaCampeona) {
    nombreCampeona = nombre;
    marcaCampeona = marca;
  }
}

// Verificar si la atleta campeona rompió el récord y mostrar los resultados
console.log("La atleta campeona es: " + nombreCampeona);
if (marcaCampeona > 15.5) {
  console.log("¡Rompió el récord! Se le otorgará un pago de 500 millones.");
}

//Ejercicio 10
/*Desarrolle un programa cíclico que capture un dato
numérico cada vez, y los vaya acumulando. El programa se
detiene cuando el usuario digita un cero. El programa debe
mostrar: LA SUMATORIA DE LOS VALORES, EL VALOR DEL
PROMEDIO, CUÁNTOS VALORES FUERON DIGITADOS, MAYOR
VALOR Y MENOR VALOR.*/ 

var suma = 0;       // Variable para almacenar la sumatoria de los valores
var cantidad = 0;   // Variable para contar la cantidad de valores ingresados
var mayor = -Infinity;  // Variable para almacenar el mayor valor (inicializada con un valor muy bajo)
var menor = Infinity;   // Variable para almacenar el menor valor (inicializada con un valor muy alto)

while (true) {
  var valor = parseFloat(prompt("Ingrese un valor (ingrese 0 para detener el programa):"));

  if (valor === 0) {
    break;  // Si el valor ingresado es cero, se detiene el programa
  }

  suma += valor;   // Se acumula el valor en la suma
  cantidad++;     // Se incrementa el contador de valores

  if (valor > mayor) {
    mayor = valor;   // Actualizar el mayor valor si se encuentra uno mayor
  }

  if (valor < menor) {
    menor = valor;   // Actualizar el menor valor si se encuentra uno menor
  }
}

var promedio = suma / cantidad;   // Calcular el promedio

console.log("Sumatoria de los valores: " + suma);
console.log("Valor del promedio: " + promedio);
console.log("Cantidad de valores digitados: " + cantidad);
console.log("Mayor valor: " + mayor);
console.log("Menor valor: " + menor);

//taller 3 punto 1
/* Construir un objeto literal "campus" que gestione
la info(PROPIEDADES) de Campus, trainers, campers, niveles,
tecnologías, teams y roadMap
1.1. De campus administrar los datos de contacto de las sedes en
Bucaramanga, Bogotá, Medellín y México
1.2. De los trainers y campers, su nombre, sus teléfonos, teams
(horarios de las teams=> día, hora y salones (nro y piso), y el
email, y de los campers también horarios de inglés y ser.
1.3. De los campers, también gestionar su nivel actual, como su
barrio y medio de transporte
1.4. De los niveles, su pre requisito, a que tecnología pertenece, si
es electiva u obligatoria
1.5. De la roadmap , Nro de créditos, año, Nro de asignaturas*/ 

var campus = {
    sedes: {
      bucaramanga: {
        contacto: {
          telefono: "123456789",
          direccion: "Calle 123, Bucaramanga"
        }
      },
      bogota: {
        contacto: {
          telefono: "987654321",
          direccion: "Carrera 456, Bogotá"
        }
      },
      medellin: {
        contacto: {
          telefono: "555555555",
          direccion: "Avenida 789, Medellín"
        }
      },
      mexico: {
        contacto: {
          telefono: "111111111",
          direccion: "Calle 789, México"
        }
      }
    },
    trainers: [
      {
        nombre: "Trainer 1",
        telefono: "111111111",
        teams: [
          {
            dia: "Lunes",
            hora: "10:00",
            salon: {
              numero: 101,
              piso: 1
            }
          },
          {
            dia: "Miércoles",
            hora: "15:00",
            salon: {
              numero: 202,
              piso: 2
            }
          }
        ],
        email: "trainer1@example.com"
      },
      {
        nombre: "Trainer 2",
        telefono: "222222222",
        teams: [
          {
            dia: "Martes",
            hora: "14:00",
            salon: {
              numero: 303,
              piso: 3
            }
          },
          {
            dia: "Jueves",
            hora: "9:00",
            salon: {
              numero: 404,
              piso: 4
            }
          }
        ],
        email: "trainer2@example.com"
      }
    ],
    campers: [
      {
        nombre: "Camper 1",
        telefono: "333333333",
        teams: [
          {
            dia: "Lunes",
            hora: "10:00",
            salon: {
              numero: 101,
              piso: 1
            }
          },
          {
            dia: "Miércoles",
            hora: "15:00",
            salon: {
              numero: 202,
              piso: 2
            }
          }
        ],
        horariosIngles: [
          {
            dia: "Martes",
            hora: "16:00",
            salon: {
              numero: 303,
              piso: 3
            }
          },
          {
            dia: "Jueves",
            hora: "11:00",
            salon: {
              numero: 404,
              piso: 4
            }
          }
        ],
        nivelActual: "Intermedio",
        barrio: "Barrio 123",
        transporte: "Transporte 123"
      },
      {
        nombre: "Camper 2",
        telefono: "444444444",
        teams: [
          {
            dia: "Lunes",
            hora: "12:00",
            salon: {
              numero: 505,
              piso: 5
            }
          },
          {
            dia: "Miércoles",
            hora: "17:00",
            salon: {
              numero: 606,
              piso: 6
            }
          }
        ],
        horariosIngles: [
          {
            dia: "Martes",
            hora: "18:00",
            salon: {
              numero:
  

//2
/*Consultas: Usando Destructuring,
2.1 De los trainers, reportar si la asignatura (tecnología) es
remota o presencial y de los campers el nombre de salón.
2.2 El teléfono de la sede de Medellín y la dirección de la
sede de Bucaramanga
2.3 De la asignatura (tecnología) si tiene sandbox o no*/ 

var campus = {
    trainers: [
      {
        nombre: "Trainer 1",
        tecnologia: "Remota"
      },
      {
        nombre: "Trainer 2",
        tecnologia: "Presencial"
      }
    ],
    campers: [
      {
        nombre: "Camper 1",
        salon: "101"
      },
      {
        nombre: "Camper 2",
        salon: "202"
      }
    ],
    sedes: {
      medellin: {
        contacto: {
          telefono: "555555555",
          direccion: "Avenida 789, Medellín"
        }
      },
      bucaramanga: {
        contacto: {
          telefono: "123456789",
          direccion: "Calle 123, Bucaramanga"
        }
      }
    },
    asignatura: {
      tecnologia: "JavaScript",
      sandbox: true
    }
  };
  
  // Consulta 2.1: Reportar si la asignatura de los trainers es remota o presencial
  var [trainer1, trainer2] = campus.trainers;
  console.log("La asignatura del Trainer 1 es " + trainer1.tecnologia);
  console.log("La asignatura del Trainer 2 es " + trainer2.tecnologia);
  
  // Consulta 2.2: Obtener el teléfono de la sede de Medellín y la dirección de la sede de Bucaramanga
  var { telefono: telefonoMedellin } = campus.sedes.medellin.contacto;
  var { direccion: direccionBucaramanga } = campus.sedes.bucaramanga.contacto;
  console.log("Teléfono de la sede de Medellín: " + telefonoMedellin);
  console.log("Dirección de la sede de Bucaramanga: " + direccionBucaramanga);
  
  // Consulta 2.3: Verificar si la asignatura tiene sandbox o no
  var { sandbox } = campus.asignatura;
  console.log("La asignatura tiene sandbox: " + sandbox);
  

//ejer 3
/*Consultas: Usando sintaxis de punto.
3.1 Reportar, prerequisito de la asignatura (tecnología) y nro de
créditos del roadmap
3.2 Agregar mas objetos con mas objetos anidados de manera libre
(por lo menos 7)*/ 

var campus = {
    asignatura: {
      tecnologia: "JavaScript",
      prerequisito: "HTML",
      creditos: 5
    },
    roadmap: {
      nroCreditos: 30,
      anio: 2023,
      nroAsignaturas: 10
    }
  };
  
  // Consulta 3.1: Obtener el prerequisito de la asignatura y el número de créditos del roadmap
  console.log("Prerequisito de la asignatura: " + campus.asignatura.prerequisito);
  console.log("Número de créditos del roadmap: " + campus.roadmap.nroCreditos);
  
  // Consulta 3.2: Agregar más objetos anidados al objeto "campus"
  campus.sedes = {
    mexico: {
      contacto: {
        telefono: "999999999",
        direccion: "Calle 456, México"
      }
    },
    madrid: {
      contacto: {
        telefono: "888888888",
        direccion: "Calle 789, Madrid"
      }
    }
  };
  
  campus.equipos = {
    equipo1: {
      nombre: "Equipo 1",
      miembros: ["Miembro 1", "Miembro 2", "Miembro 3"]
    },
    equipo2: {
      nombre: "Equipo 2",
      miembros: ["Miembro 4", "Miembro 5", "Miembro 6"]
    }
  };
  
  console.log(campus);
  




//Ejercicio ej
//Crear una funcion que se carge al inicio y que muestre la suma de dos numeros

//Crear funcion
function sumaNumero()

    //Obtener valores ingreesados por los usuarios
    let num1= (prompt("Ingreese el primer numero"));
    let num2= (prompt("Ingrese el segundo numero"));

    //Calcular suma
    let suma = num1 + num2;
    document.write("la suma de los dos numeros es:"+ suma);
//Solo recibe numeros enteros,pero si recibe numeros decimales a diferencia de parseInt



