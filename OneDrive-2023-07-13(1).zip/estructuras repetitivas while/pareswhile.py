"""
EJERCICIO 1
Imprimir los numeros pares que hay de 1 a 100
"""

par = 2
while par <=100:
    print(par, end=", ")
    par = par + 2
    