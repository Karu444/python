import random

for i in range(10):
    print(random.randrange(1, 101), end=", ")