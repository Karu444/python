# for i in range (1, 10):
#     if i == 5:
#         continue
#     print(i, end=", ")
    
# print("FIN PROGRAMA")

for numero in range(1, 11):
    if numero % 2 == 0:
        continue
    print(numero)
