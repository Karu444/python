import Math

num = int(input("Numero? "))

dig = int(Math.log(num)) + 1

print("Cantidad de digitos: ", dig)

