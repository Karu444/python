# for i in range(6):
#     print(i, end=", ")
    
# for i in range(-1, 5):
#     print(i, end=", ")

# for i in range(-1, 5, 2):
#     print(i, end=", ")

# for i in range(5, 1, -2):
#     print(i, end=", ")
    
