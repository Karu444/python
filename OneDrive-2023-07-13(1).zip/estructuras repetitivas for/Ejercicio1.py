"""
EJERCICIO 1
Imprimir los numeros pares que hay de 1 a 100
"""

for par in range(2, 101, 2):
    print(par, end=", ")