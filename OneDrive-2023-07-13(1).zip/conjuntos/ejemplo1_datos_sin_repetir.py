lstnombre = ["Carlos", "Diana", "Oscar", "Carlos", "Javier"]
lstNomSinRep = list(set(lstnombre))
print(lstnombre)
print(lstNomSinRep)
