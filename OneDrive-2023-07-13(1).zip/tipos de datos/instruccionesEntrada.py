variable = float(input("Ingrese su temperatura: "))
print(type(variable))