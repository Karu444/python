fd = open("codigo/archivos/prueba.txt", "w")
fd.write("Primera linea\n")
fd.write("Segunda linea\n")
fd.close()